package seleniumPackage;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.DataTable;

public class seleniumCode {
	public static WebDriver driver;
	
	public void walesPerson()
	{
		driver = new ChromeDriver();
		driver.get("https://services.nhsbsa.nhs.uk/check-for-help-paying-nhs-costs/start");
		driver.manage().window().maximize();			
		driver.findElement(By.id("next-button")).click();
		driver.findElement(By.id("label-wales")).click();
		driver.findElement(By.id("next-button")).click();
	}
	
	public void circumstances(DataTable circumstancesTable)
	{
		List<List<String>> list = circumstancesTable.asLists(String.class);
		int i = 1;
		driver.findElement(By.id("dob-day")).sendKeys(list.get(i).get(0).toString());
		driver.findElement(By.id("dob-month")).sendKeys(list.get(i).get(1).toString());
		driver.findElement(By.id("dob-year")).sendKeys(list.get(i).get(2).toString());
		driver.findElement(By.id("next-button")).click();
		String Partner = list.get(i).get(3).toString();
		String BenefitsTaxClaim = list.get(i).get(4).toString();
		String PregnantLast12Months = list.get(i).get(5).toString();
		String ArmedForcesInjuryIllness = list.get(i).get(6).toString();
		String Diabetes = list.get(i).get(7).toString();
		String Glaucoma = list.get(i).get(8).toString();
		String Carehome = list.get(i).get(9).toString();
		String moreThan16kSavings = list.get(i).get(10).toString();
		System.out.println("Partner: " + Partner);
		System.out.println("BenefitsTaxClaim: " + BenefitsTaxClaim);
		System.out.println("PregnantLast12Months: " + PregnantLast12Months);
		System.out.println("ArmedForcesInjuryIllness: " + ArmedForcesInjuryIllness);
		System.out.println("Diabetes: " + Diabetes);
		System.out.println("Glaucoma: " + Glaucoma);
		System.out.println("Carehome: " + Carehome);
		System.out.println("moreThan16kSavings: " + moreThan16kSavings);
		if (Partner.equals("Yes")) {
			driver.findElement(By.id("label-yes")).click();
			} else driver.findElement(By.id("label-no")).click();
		driver.findElement(By.id("next-button")).click();
		if (BenefitsTaxClaim.equals("Yes")) {
			driver.findElement(By.id("label-yes")).click();
			} else driver.findElement(By.id("label-no")).click();
		driver.findElement(By.id("next-button")).click();
		if (PregnantLast12Months.equals("Yes")) {
			driver.findElement(By.id("label-yes")).click();
			} else driver.findElement(By.id("label-no")).click();
		driver.findElement(By.id("next-button")).click();
		if (ArmedForcesInjuryIllness.equals("Yes")) {
			driver.findElement(By.id("label-yes")).click();
			} else driver.findElement(By.id("label-no")).click();
		driver.findElement(By.id("next-button")).click();
		if (Diabetes.equals("Yes")) {
			driver.findElement(By.id("label-yes")).click();
			} else driver.findElement(By.id("label-no")).click();
		driver.findElement(By.id("next-button")).click();
		if (Glaucoma.equals("Yes")) {
			driver.findElement(By.id("label-yes")).click();
			} else driver.findElement(By.id("label-no")).click();
		driver.findElement(By.id("next-button")).click();
		if (Carehome.equals("Yes")) {
			driver.findElement(By.id("label-yes")).click();
			} else driver.findElement(By.id("label-no")).click();
		driver.findElement(By.id("next-button")).click();
		if (moreThan16kSavings.equals("Yes")) {
			driver.findElement(By.id("label-yes")).click();
			} else driver.findElement(By.id("label-no")).click();
		driver.findElement(By.id("next-button")).click();
	}
	
	public void result()
	{
		WebElement result = driver.findElement(By.id("result-heading"));
		System.out.println("Result: " + result.getText());
		driver.quit();
	}
}
