package stepDefinitions;

import cucumber.api.DataTable;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import seleniumPackage.seleniumCode;

public class steps {
	
	seleniumCode selenium = new seleniumCode();
	
	@Given("^I am a person from Wales with the following circumstances$")
	public void walesPerson() throws Exception{
		System.setProperty("webdriver.chrome.driver","./chromedriver/chromedriver.exe");
		System.setProperty("webdriver.chrome.driver",".//CucumberNHS/chromedriver/chromedriver.exe");
		selenium.walesPerson();
	}

	@When("^I put my circumstances into the checker tool$")
	public void checkerToolCircumstances(DataTable circumstancesTable) throws Exception{
		selenium.circumstances(circumstancesTable);
	}

	@Then("^I should get a result of whether I will get help or not$")
	public void results() throws Exception{
		selenium.result();
	}

}
