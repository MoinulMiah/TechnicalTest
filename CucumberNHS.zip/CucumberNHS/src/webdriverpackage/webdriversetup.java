package webdriverpackage;

import org.openqa.selenium.WebDriver;

public class webdriversetup {
public static WebDriver driver;
}
